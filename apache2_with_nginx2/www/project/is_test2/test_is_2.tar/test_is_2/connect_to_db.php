<?php  
define('DB_HOST', '192.168.10.236');
define('DB_USER', 'root');
define('DB_PASS', 'pass12q!2');
define('DB_NAME', 'is');
?>
